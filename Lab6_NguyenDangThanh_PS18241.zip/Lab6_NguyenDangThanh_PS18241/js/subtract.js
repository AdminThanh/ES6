subtract = (x, y) => x - y;
export default function subtract() { };