const lowercaseString = (String) => {
    return String.toLowerCase();
}
export {lowercaseString};