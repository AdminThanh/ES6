const uppercaseString = (String) => {
    return String.toUpperCase();
}
export {uppercaseString};