const name = "James";
console.log(name);

const Person = { firstName: "name" };
console.log(Person);

const helloLinting = (fname) => {
  console.log(fname);
};
helloLinting("James");
