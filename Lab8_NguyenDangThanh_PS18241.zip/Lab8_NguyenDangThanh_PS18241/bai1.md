# Firebase là gì ?
    - Firebase là một nền tảng để phát triển ứng dụng di động và trang web, bao gồm các API đơn giản và mạnh mẽ mà không cần backend hay server.
# Ưu điểm khi sử dụng firebase
    - Tạo tài khoản và sử dụng dễ dàng
    - Tốc độ phát triển nhanh
    - Nhiều dịch vụ trong một nền tảng
    - Được cung cấp bởi Google 
    - Tập trung vào phát triển giao diện người dùng 
    - Firebase không có máy chủ
    - Học máy (Machine Learning)
    - Tạo lưu lượng truy cập
    - Theo dõi lỗi
    - Sao lưu

# Nhược điểm khi sử dụng firebase
    - Không phải là mã nguồn mở
    - Người dùng không có quyền truy cập mã nguồn
    - Firebase không hoạt động ở nhiều quốc gia
    - Chỉ hoạt động với Cơ sở dữ liệu NoSQL
    - Truy vấn chậm
    - Không phải tất cả các dịch vụ Firebase đều miễn phí
    - Firebase khá đắt và giá không ổn định
    - Chỉ chạy trên Google Cloud
    - Thiếu Dedicated Servers và hợp đồng doanh nghiệp
    - Không cung cấp các API GraphQL